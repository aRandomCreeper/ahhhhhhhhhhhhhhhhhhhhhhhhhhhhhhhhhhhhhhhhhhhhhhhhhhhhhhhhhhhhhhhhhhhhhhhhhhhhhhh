# pro53didyou-know


Let's Get Started Coder!!
Fill the following Document
__________________________________________________________________________

1. Which one of the following is an Imperative Language??

HTML
CSS
Java Script

Answer: 	

	Java Script

2. Which one of the following is a Declarative Language??

HTML
CSS
Java Script

Answer: 

	HTML

3. Name two uses of a DIV tag??

Answer:

	To create a container in code
	To create a reference for CSS styling.

4. What is the difference between relative positioning and absolute positioning in HTML?

Answer: 

	Relative positioning is when a component is made so that it can be offset from its original position, and absolute positioning is when a component can be positioned in relation to the box that it is in.

5. What is the use of opacity in CSS??

Answer: 

To change the visibility of components.
6. Which is the programming language used in the React Native Framework??

Answer: 
JSX, which is a mix of Js, HTML, and CSS.

7. Which online editor are we using for creating our apps in React Native Framework??

Answer: 

Snack

8. Write the steps to test your first designed app in the online editor on a mobile.

Answer:
choose your device - iOS or android.
click on run on device.
download Expo on your device
use your mobile to scan the barcode that is given.
Open the result in the Expo app.

9. What is the use of the render function in React Native Framework??

Answer: 

To render the code to send it to the app so that it can be seen in the output screen.


10. What is the use of return function  in React Native Framework??

Answer:

To give the render function the instructions in a single argument.

11. What are the various components in your first app that you designed??

Answer: 

Button, View, and Text
